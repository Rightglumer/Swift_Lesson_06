import Cocoa

protocol Named {
    var name : String { get set }
}

struct Quene<T : Named> {
    private var elements: [T] = []
    
    mutating func addElement(_ element : T) {
        elements.append(element)
    }
    
    mutating func getElement() -> T? {
        let returnElement = elements.first;
        elements.removeFirst();
        return returnElement;
    }
    
    mutating func getElementByIndex(index : Int) -> T? {
        if index > elements.count {
            return nil
        } else {
            return elements[index];
        }
    }
    
    func getElementsByFilter(filterName : String) -> [T]? {
        var returnArray = [T]();
        var currentName : String;
        for element in elements {
            currentName = element.name.uppercased()
            if currentName.contains(filterName.uppercased()) {
                returnArray.append(element);
            }
        }
        return returnArray;
    }
    
    subscript (elemIndex: Int ...) -> String {
        var resultStr : String = ""
        for idx in elemIndex where idx < elements.count {
            resultStr += ", '" + elements[idx].name + "'";
        }
        if resultStr != "" {
            resultStr = String(resultStr.dropFirst(2));
        }
        return resultStr
    }
    
    func printNames(inputArray : [T]) {
        for element in inputArray {
            print(element.name)
        }
    }
    
    func printNames() {
        for element in elements {
            print(element.name)
        }
    }
}

class CarShop : Named{
    var name : String;
    
    func getName() -> String {
        return name
    }
    
    func setName(name : String){
        self.name = name;
    }
    
    init(name : String){
        self.name = name;
    }
}

class ActorsCasting : Named{
    var name : String;
    
    func setName(name : String){
        self.name = name;
    }
    
    init(name : String){
        self.name = name;
    }
}

var dealers = Quene<CarShop>()

dealers.addElement(CarShop(name: "Гермес Авто"))
dealers.addElement(CarShop(name: "Инком авто"))
dealers.addElement(CarShop(name: "Газ"))

print("Subscript")
print(dealers[0, 2, 5])
print("-- filtered")
dealers.printNames(inputArray: dealers.getElementsByFilter(filterName: "авто")!)
print("---- get index 4")
print(dealers.getElementByIndex(index: 4)?.name)
print("---- get index 1")
print(dealers.getElementByIndex(index: 1)?.name)
print("---- get element")
print(dealers.getElement()?.name)
print("---- after all")
dealers.printNames()
